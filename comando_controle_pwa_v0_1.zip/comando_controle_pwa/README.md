# COMANDO DE CONTROLE — Operação Última Asa
## Build 0.1 — PWA + IndexedDB

Este projeto é uma primeira fundação funcional. Ele salva dados no navegador/dispositivo usando IndexedDB e pode ser instalado como PWA quando publicado em hospedagem HTTPS.

### Funcionalidades
- Painel de personagem, XP, nível, créditos e atributos.
- Registro de estudo com cálculo de XP.
- Missão inicial com objetivos e recompensa de XP, créditos e loot.
- Inventário de materiais.
- Oficina com receitas de fabricação.
- Histórico de operações.
- Exportação e importação de backup JSON.
- Cache básico para abertura offline após o primeiro acesso.

### Publicação gratuita sugerida: GitHub Pages
1. Crie uma conta em https://github.com/ se ainda não tiver.
2. Crie um repositório público chamado `comando-controle`.
3. Envie todos os arquivos desta pasta para a raiz do repositório.
4. No repositório, abra **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/ (root)`, depois salve.
7. Aguarde a publicação. O GitHub exibirá um endereço `https://SEU-USUARIO.github.io/comando-controle/`.

### Instalar no Android
1. Abra o endereço publicado no Chrome do Android.
2. Abra o menu ⋮.
3. Escolha **Instalar app** ou **Adicionar à tela inicial** (a opção pode variar).
4. Abra pelo ícone COMANDO.

### Persistência e segurança
- Os dados ficam no armazenamento do navegador deste dispositivo.
- Limpar dados do site/navegador pode apagar o banco local.
- Exporte um backup JSON periodicamente e guarde-o em local seguro.
- A nuvem ainda não está implementada.
- Para outro celular, importe o backup exportado.

### Regras da primeira versão
- XP por página: 1.
- Questão fora de mapeamento: 2 XP.
- Acerto: +1 XP.
- Erro corrigido e compreendido: +1 XP.
- Mapeamento: +30 XP.
- Revisão: +25 XP.
- Apostila: +50 XP.
- Matéria: +250 XP.
- Simulado: +50 XP.

O formulário contabiliza questões avulsas fora de mapeamentos para evitar duplicidade de XP. O sistema é um protótipo funcional: ainda não possui autenticação, sincronização em nuvem, validação avançada contra duplicidade ou lógica completa de progressão narrativa.
